<?php

$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");
$email=$_POST['email'];


$sql = "SELECT * FROM book INNER JOIN user_list ON book.title=user_list.book_name AND user_list.user_email='$email'";
if ($result = mysqli_query($con,$sql))
  {
   $emparray = array();
   while($row =mysqli_fetch_assoc($result))
       $emparray[] = $row;

  echo(json_encode($emparray));
  mysqli_free_result($result);
  mysqli_close($con);
}