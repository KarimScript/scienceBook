<?php
$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");

if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		
		$email=$_POST['email'];
		$password=$_POST['password'];

		$que=mysqli_query($con,"select * from user where email ='$email' and password='$password'");
		$row=mysqli_num_rows($que);

		if($row>0)
		{

	           $result["success"] = "1";
		       $result["message"] = "Successful";

		       
		       echo json_encode($result);
	        	
	        }

		else
			{

		$result["success"] = "0";
		$result["message"] = "Incorrect email or password";

		
		 echo json_encode($result);
				
			}
	}