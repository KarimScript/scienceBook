<?php

$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $email = $_POST['email'];
    $bookname= $_POST['bookName'];

    $check= "SELECT * FROM user_list WHERE user_email='$email' AND book_name='$bookname'";
    $result=mysqli_query($con,$check);
    $row=mysqli_num_rows($result);
    if($row>0){
        echo 'this book already in your list';
    }
    else{
        $sql='INSERT INTO user_list(user_email, book_name) VALUES ("'.$email.'","'.$bookname.'")';
    mysqli_query($con,$sql) or
    die ("can't add to list");
   
    echo "Added to list!";

    mysqli_close($con);
     
    }



    
}
    

    