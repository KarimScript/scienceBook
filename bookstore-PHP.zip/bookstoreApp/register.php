<?php
$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	
    $name = $_POST['name'];
    $email= $_POST['email'];
    $password = $_POST['password']
    
    $check_query = "SELECT * FROM user WHERE email='$email' ";
    $check_result_query =mysqli_fetch_array(mysqli_query($con,$check_query));
    
    if (isset($check_result_query)) {
        
          echo "Email already exist,choose another";
    }
    
    else{
    
       
    $sql=mysqli_query($con, 'INSERT INTO user(id, name, email, password)
             VALUES( ",'.$name.'","'.$email.'","'.$password.'")');
    
    
             if (!$sql) {
             die (mysqli_error($con));
             }
    
    else {
    
           echo "registration succeed!";
    }
    
    }}
    else{
            echo "access denied";
    }
    
    
    