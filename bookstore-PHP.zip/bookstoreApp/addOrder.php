<?php
$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $email=$_POST['email'];
    $bookname=$_POST['bookName'];
    $amount=$_POST['amount'];
    $username=$_POST['username'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];
    $zipcode=$_POST['zipcode'];

    $query="INSERT INTO `order`(`id`, `amount`, `phone`, `username`, `useraddress`, `zipCode`, `bookname`, `user_email`) VALUES (DEFAULT,'$amount','$phone','$username','$address','$zipcode','$bookname','$email')";
    mysqli_query($con,$query) or die (mysqli_error($con));

    echo "Order sent successfully !";
    mysqli_close($con);
}

