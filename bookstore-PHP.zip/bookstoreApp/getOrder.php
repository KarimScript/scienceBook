<?php
$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");
if($_SERVER['REQUEST_METHOD'] == 'POST'){
$email=$_POST['email'];

  
$sql = "SELECT * FROM order WHERE user_email='$email'";
if ($result = mysqli_query($con,$sql))
  {
   $array = array();
   while($rows =mysqli_fetch_assoc($result))
       $array[] = $rows;

  echo(json_encode($array));
  mysqli_free_result($result);
  mysqli_close($con);
}
}