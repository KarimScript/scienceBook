<?php
$con=mysqli_connect("localhost","id18164355_karim", "L[glzZlYJu4=q(c?","id18164355_bookstore");

if (mysqli_connect_errno())
  {
  echo "Failed to connect to DATABASE: " . mysqli_connect_error();
  }

$sql = "SELECT * FROM book";
if ($result = mysqli_query($con,$sql))
  {
   $emparray = array();
   while($row =mysqli_fetch_assoc($result))
       $emparray[] = $row;

  echo(json_encode($emparray));
  mysqli_free_result($result);
  mysqli_close($con);
}
