-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 04, 2022 at 05:19 PM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id18164355_bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`title`, `author`, `image`, `price`, `description`) VALUES
('180 Days of Math', 'Jodene Smith', 'https://images-na.ssl-images-amazon.com/images/I/51ExqHDpx0L._SX218_BO1,204,203,200_QL40_FMwebp_.jpg', 20.99, '180 Days of Math: Grade 3 - Daily Math Practice Workbook for Classroom and Home, Cool and Fun Math, Elementary School Level Activities Created by Teachers to Master Challenging Concepts.'),
('AP Chemistry Premium Prep', 'The Princeton Review ', 'https://images-na.ssl-images-amazon.com/images/I/51ohXr3uTjL._SX384_BO1,204,203,200_.jpg', 17.62, 'EVERYTHING YOU NEED TO HELP SCORE A PERFECT 5, WITH THE BEST PRACTICE ON THE MARKET! Equip yourself to ace the AP Chemistry Exam with this comprehensive study guide'),
('Basic Mathematics', 'Serge lang', 'https://m.media-amazon.com/images/P/0387967877.01._SCLZZZZZZZ_SX500_.jpg\r\n', 42.3, 'This text in basic mathematics is ideal for high school or college students. It provides a firm foundation in basic principles of mathematics and thereby acts as a springboard into calculus, linear algebra and other more advanced topics. The information i'),
('Basic Physics', 'Karl F. Kuhn', 'https://images-na.ssl-images-amazon.com/images/I/41Ky3+4CvuL._SX397_BO1,204,203,200_.jpg', 18.99, 'Basic Physics: A Self-Teaching Guide, 3rd Edition is the most practical and reader-friendly guide to understanding all basic physics concepts and terms. The expert authors take a flexible and interactive approach to physics based on new research-based met'),
('Brains Explained', 'Alison Caldwell PhD', 'https://images-na.ssl-images-amazon.com/images/I/51ynsDmKS8L._SX218_BO1,204,203,200_QL40_FMwebp_.jpg', 18.08, 'How They Work & Why They Work That Way | STEM Learning about the Human Brain | Fun and Educational Facts about Human Body'),
('Campbell Biology', 'Lisa Urry', 'https://images-na.ssl-images-amazon.com/images/I/51xSdEZMNgL._SX258_BO1,204,203,200_.jpg', 30, 'The Eleventh Edition of the best-selling Campbell BIOLOGY sets students on the path to success in biology through its clear and engaging narrative, superior skills instruction, innovative use of art and photos, and fully integrated media resources to enha'),
('Chemistry Essentials', 'jhon T.Moore ', 'https://images-na.ssl-images-amazon.com/images/I/413UFRBb6FL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg', 9.09, 'Available at a lower price from other sellers that may not offer free Prime shipping.Chemistry Essentials For Dummies (9781119591146) was previously published as Chemistry Essentials For Dummies (9780470618363). While this version features a new Dummies c'),
('Chemistry Made Easy', 'NEDU', 'https://images-na.ssl-images-amazon.com/images/I/51wo-TM7UtS._SX218_BO1,204,203,200_QL40_FMwebp_.jpg', 13.6, 'This book includes over 300 illustrations to help you visualize what is necessary to understand chemistry at it\'s core. While Chemistry is a huge topic, it\'s not necessary to spend years studying it unless it\'s your major in college. For most of us, we ne'),
('Hands-On Math', 'Judith Muschla', 'https://images-na.ssl-images-amazon.com/images/I/61VgTxK0vvL._SX385_BO1,204,203,200_.jpg', 24.05, 'Hands-On Math Projects with Real-Life Applications, Second Edition offers an exciting collection of 60 hands-on projects to help students in grades 6--12 apply math concepts and skills to solving everyday, real-life problems! The book is filled with class'),
('helgoland', 'Carlo Rovelli', 'https://images-na.ssl-images-amazon.com/images/I/51+q6cyliVL._SX321_BO1,204,203,200_.jpg', 11, 'Helgoland is a treeless island in the North Sea where the twenty-three-year-old Werner Heisenberg made the crucial breakthrough for the creation of quantum mechanics, setting off a century of scientific revolution.'),
('HMH Modern chemistry', 'HOUGHTON HARCOURT', 'https://images-na.ssl-images-amazon.com/images/I/513K-wKeGRL._SX392_BO1,204,203,200_.jpg', 66.89, 'HMH Modern Chemistry: Student Edition 2017 1st Edition '),
('Hmh Physics', 'Houghton Harcourt', 'https://images-na.ssl-images-amazon.com/images/I/51XqKJuKCFL._SX218_BO1,204,203,200_QL40_FMwebp_.jpg', 41.3, 'Hard Cover. No markings or underlines in book. It has the last name, West ,written in Sharpie on the bottom of the book page binding. Bought new and used for one school year.'),
('Holt Physics', 'RINEHART', 'https://images-na.ssl-images-amazon.com/images/I/51LoDDGlysL._SX385_BO1,204,203,200_.jpg', 66, 'Available at a lower price from other sellers that may not offer free Prime shipping.'),
('Immune', 'Philipp Dettmer', 'https://m.media-amazon.com/images/I/51wCC2IwLLL.jpg', 11.7, 'You wake up and feel a tickle in your throat. Your head hurts. You’re mildly annoyed as you get the kids ready for school and dress for work yourself. Meanwhile, an epic war is being fought, just below your skin. Millions are fighting and dying for you to'),
('Mastering Essential', 'Richard W Fisher', 'https://images-na.ssl-images-amazon.com/images/I/51hx7r9ZzcL._SX384_BO1,204,203,200_.jpg', 21.9, 'Mastering Essential Math Skills, Book 1: Grades 4 and 5, 3rd Edition: 20 minutes a day to success. '),
('Math basics', 'School Zone', 'https://images-na.ssl-images-amazon.com/images/I/51SDS--c-xL._SX358_BO1,204,203,200_.jpg', 3.5, 'Math Basics 3 Workbook - 64 Pages, Ages 8 to 9, 3rd Grade, Multiplication, Division, Word Problems, Place Value, Fractions, and More (School Zone I Know It!® Workbook Series)'),
('Math Curse', 'Jon Scieszka', 'https://images-na.ssl-images-amazon.com/images/I/61Com36w48L._SX218_BO1,204,203,200_QL40_FMwebp_.jpg', 16.8, 'Did you ever wake up to one of those days where everything is a problem? You have 10 things to do, but only 30 minutes until your bus leaves. Is there enough time? You have 3 shirts and 2 pairs of pants. Can you make 1 good outfit? Then you start to wonde'),
('Math Geek', 'Raphael Rosen', 'https://d28hgpri8am2if.cloudfront.net/book_images/onix/cvr9781440583810/math-geek-9781440583810_lg.jpg', 32, 'Math Geek was made for you! With this guide, you\'ll learn even more about the power of numbers as you explore their brilliant nature in ways you\'ve never imagined. From manhole covers to bubbles to subway maps, each page gives you a glimpse of the world t'),
('Modern VLSI Devices', 'Yuan Taur', 'https://images-na.ssl-images-amazon.com/images/I/5168H0zMp6L._SX344_BO1,204,203,200_.jpg', 64.99, 'A thoroughly updated third edition of an classic and widely adopted text, perfect for practical transistor design and in the classroom. Covering a variety of recent developments, the internationally renowned authors discuss in detail the basic properties '),
('Mometrix', 'MAE', 'https://images-na.ssl-images-amazon.com/images/I/51eqCL4q41L._SX384_BO1,204,203,200_.jpg ', 23.5, 'Mometrix Test Preparation\'s Mechanical Aptitude Test Secrets Study Guide is the ideal prep solution for anyone who wants to pass their Mechanical Aptitude Exam. The exam is extremely challenging, and thorough test preparation is essential for success. '),
('Organic Chemistry', 'Arthurn Winter', 'https://images-na.ssl-images-amazon.com/images/I/51C-77-EsYL._SX397_BO1,204,203,200_.jpg', 8.88, 'Organic Chemistry I For Dummies, 2nd Edition (9781119293378) was previously published as Organic Chemistry I For Dummies, 2nd Edition (9781118828076). While this version features a new Dummies cover and design, the content is the same as the prior release'),
('Photovoltaic Systems', 'NJAT', 'https://images-na.ssl-images-amazon.com/images/I/51T08-5CQLL._SX380_BO1,204,203,200_.jpg', 141, 'Photovoltaic Systems is a comprehensive guide to the design and installation of several types of residential and commercial PV systems. Numerous illustrations explain the concepts behind how PV arrays and other components operate, and photographs of actua'),
('Practical Math', ' LLC Editors', 'https://images-na.ssl-images-amazon.com/images/I/51XibGQr27L._SX388_BO1,204,203,200_.jpg', 7.37, 'LearningExpress\'s 20 Minutes a Day guides make challenging subject areas more accessible by tackling one small part of a larger topic and building upon that knowledge with each passing day. Practical Math Success in 20 Minutes a Day features'),
('Prentice Hall Chemistry ', 'Anthony Wibragham', 'https://images-na.ssl-images-amazon.com/images/I/51Z6Jr9FD-L._SX218_BO1,204,203,200_QL40_FMwebp_.jpg', 29.89, 'Prentice Hall Chemistrymeets the needs of students with a range of abilites, diversities, and learning styles by providing real-world connections to chemical concepts and processes. The first nine chapters introduce students to the conceptual nature of ch'),
('Quantum Physics', 'Edwin Hines', 'https://images-na.ssl-images-amazon.com/images/I/51hEW7VdORL._SX331_BO1,204,203,200_.jpg', 18, 'QUANTUM PHYSICS FOR BEGINNERS: DISCOVER THE SCIENCE OF QUANTUM MECHANICS AND LEARN THE MOST IMPORTANT CONCEPTS CONCERNING BLACK HOLES STRINGS THEORY AND WHAT WE PERCEIVE AS REALITY IN A SIMPLE WAY'),
('Solar Power', 'Diy Source', 'https://images-na.ssl-images-amazon.com/images/I/41TAUGkvtJL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg', 16, 'DIY SOLAR POWER FOR BEGINNERS: A TECHNICAL GUIDE ON HOW TO DESIGN, INSTALL AND MAINTAIN GRID TIED AND OFF GRID SOLAR POWER SYSTEMS FOR YOUR HOME.'),
('SPACESHIP CREWMATE', 'Eric Parson', 'https://images-na.ssl-images-amazon.com/images/I/4121lrzlc8L._SX326_BO1,204,203,200_.jpg', 5.99, 'Follow Leo as he graduates from space academy and heads into space the first time. He loves everything about working as a crewmate until strange things start happening all over the ship. Has an alien infiltrated their ranks? Leo and his friends need to fi'),
('The Central Science', 'Brown Theodore ', 'https://images-na.ssl-images-amazon.com/images/I/51b3DMt6H3L._SX389_BO1,204,203,200_.jpg', 64, 'Chemistry: The Central Science the leading general chemistry text for more than a decade. Trusted, innovative, and calibrated, the text increases conceptual understanding and leads to greater student success in general chemistry by building on the experti'),
('The Physics book', 'DK', 'https://images-na.ssl-images-amazon.com/images/I/51d3ev2FC5L._SX419_BO1,204,203,200_.jpg', 21.37, 'Written in clear English, The Physics Book is packed with short, pithy explanations that cut through technical language, step-by-step diagrams that untangle knotty theories, memorable quotes, and witty illustrations that play with our understanding of phy'),
('Understanding Maths', 'Graham Lawler', 'http://www.graham-lawler.com/wp-content/uploads/2014/04/UNDER-MATHS-FRNT-Book-Cover_4000-600pix001.jpg', 15.6, 'For students nurses, student teachers, functional skills/ Essential Skills Wales/ Core Skills Scotland/ Core Skills Northern Ireland (* Application of Number)');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `amount` varchar(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `useraddress` varchar(255) NOT NULL,
  `zipCode` varchar(30) NOT NULL,
  `bookname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `amount`, `phone`, `username`, `useraddress`, `zipCode`, `bookname`, `user_email`) VALUES
(2, '17.62$', '70899988', 'Karim ', 'Nabatieh ', '123', 'AP Chemistry Premium Prep', 'karimgh@gmail.com'),
(3, '20.99$', '70123456', 'Karim', 'Nabatieh ', '123', '180 Days of Math', 'karimgh@gmail.com'),
(8, '20.99$', '70987654', 'Hassan', 'Nabatieh', '1700', '180 Days of Math', 'hassan@gmail.com'),
(9, '17.62$', '70111222', 'Ali', 'Nabatieh', '1700', 'AP Chemistry Premium Prep', 'ali123@gmail.com'),
(10, '20.99$', '70123456', 'Karim', 'Nabatieh', '1700', '180 Days of Math', 'karim1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `password`) VALUES
('Abbas', 'abbas@gmail.com', 'abbas123'),
('Abdallah ', 'Abdallah@gmail.com', 'abdallah123'),
('Abdallah ', 'abdallahakil56@gmail.com', 'abdallah'),
('Ahmad', 'ahmad@gmail.com', 'ahmad123'),
('Ali', 'ali123@gmail.com', 'ali1234'),
('Ali', 'ali12gmail.com', 'ali1'),
('Ali Gh', 'aligh@gmail.com', 'ali123'),
('Hassan', 'hassan@gmail.com', 'hassan123'),
('Hsein', 'hsein@gmail.com', 'hsein123'),
('Karim', 'karim1@gmail.com', 'karim1'),
('Karim Ghamlouch', 'karim@gmail.com', 'karim123'),
('karim', 'karimgh@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `user_list`
--

CREATE TABLE `user_list` (
  `user_email` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `book_name` varchar(255) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_list`
--

INSERT INTO `user_list` (`user_email`, `book_name`) VALUES
('karimgh@gmail.com', 'AP Chemistry Premium Prep'),
('karimgh@gmail.com', '180 Days of Math'),
('karimgh@gmail.com', 'Basic Mathematics'),
('karimgh@gmail.com', 'Brains Explained'),
('aligh@gmail.com', 'AP Chemistry Premium Prep'),
('aligh@gmail.com', '180 Days of Math'),
('aligh@gmail.com', 'Chemistry Made Easy'),
('abbas@gmail.com', '180 Days of Math'),
('ahmad@gmail.com', '180 Days of Math'),
('hassan@gmail.com', '180 Days of Math'),
('ali123@gmail.com', '180 Days of Math'),
('ali123@gmail.com', 'AP Chemistry Premium Prep'),
('karim1@gmail.com', '180 Days of Math'),
('karim1@gmail.com', 'AP Chemistry Premium Prep');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`title`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookid` (`bookname`),
  ADD KEY `Uemail` (`user_email`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_list`
--
ALTER TABLE `user_list`
  ADD KEY `user_email` (`user_email`),
  ADD KEY `bookname` (`book_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `Bname` FOREIGN KEY (`bookname`) REFERENCES `book` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Uemail` FOREIGN KEY (`user_email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_list`
--
ALTER TABLE `user_list`
  ADD CONSTRAINT `bookname` FOREIGN KEY (`book_name`) REFERENCES `book` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_list_ibfk_1` FOREIGN KEY (`user_email`) REFERENCES `user` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
